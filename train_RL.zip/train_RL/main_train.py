import torch.nn as nn
from torch.optim import Adam, lr_scheduler
import math
import os
import random
import time
from collections import deque
from copy import deepcopy
import numpy as np
import torch
import argparse
from buffer import ReplayBuffer, PrioritizedReplayBuffer
from model import Network
from environment import Environment, action_list
import config
from search import find_path
import sys
import argparse


np.warnings.filterwarnings('ignore', category=np.VisibleDeprecationWarning)

def learn(env, args):
    number_timesteps = config.number_timesteps
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    save_path = './models'
    save_interval = config.save_interval
    gamma = config.gamma
    grad_norm = config.grad_norm
    double_q = config.double_q
    dueling = config.dueling
    exploration_final_eps = config.exploration_final_eps
    batch_size = config.batch_size
    train_freq = config.train_freq
    learning_starts = config.learning_starts
    target_network_update_freq = config.target_network_update_freq
    buffer_size = config.buffer_size
    prioritized_replay = config.prioritized_replay
    prioritized_replay_alpha = config.prioritized_replay_alpha
    prioritized_replay_beta0 = config.prioritized_replay_beta0

    network = Network(subgoal_or_not = env.subgoal_or_not,punish = env.punish,
                      setting_of_oscillation=env.setting_of_oscillation,dueling=dueling)
    # print("Total number of paramerters in networks is {}  ".format(sum(x.numel() for x in network.parameters())))

    qnet = network.to(device)
    tar_qnet = deepcopy(qnet)


    optimizer = Adam(qnet.parameters(), lr=1e-4)
    scheduler = lr_scheduler.StepLR(optimizer, 95000, gamma=0.5)

    # create replay buffer
    if prioritized_replay:
        buffer = PrioritizedReplayBuffer(buffer_size, device, prioritized_replay_alpha, prioritized_replay_beta0)
    else:
        buffer = ReplayBuffer(buffer_size, device)


    generator = _generate(device, env, qnet, number_timesteps, exploration_final_eps)

    start_ts = time.time()
    for n_iter in range(1, number_timesteps + 1):
        # ------------------------------------------------#
        sys.stdout.write("\r the n_iter is: %d" % (n_iter))
        sys.stdout.flush()
        # time.sleep(0.1)
        # -------------------------------------------------#
        if prioritized_replay:
            buffer.beta += (1 - prioritized_replay_beta0) / number_timesteps
        data = generator.__next__()
        buffer.add(data)
        # b_obs, b_action, b_reward, b_obs_, b_done, b_steps

        # update qnet
        if n_iter > learning_starts and n_iter % train_freq == 0:
            b_obs, b_action, b_reward, b_obs_, b_done, b_steps, *extra = buffer.sample(batch_size)

            with torch.no_grad():
                # choose max q index from next observation
                if double_q:
                    # TORCH.UNSQUEEZE https://pytorch.org/docs/stable/generated/torch.unsqueeze.html
                    q_temp = qnet(b_obs_)
                    b_action_ = q_temp.argmax(1).unsqueeze(1)
                    b_q_ = (1 - b_done) * tar_qnet(b_obs_).gather(1, b_action_)
                else:
                    q_temp = tar_qnet(b_obs_)
                    b_q_ = (1 - b_done) * q_temp.max(1, keepdim=True)[0]

            b_q = qnet(b_obs).gather(1, b_action)
            abs_td_error = (b_q - (b_reward + (gamma ** b_steps) * b_q_)).abs()
            priorities = abs_td_error.detach().cpu().clamp(1e-6).numpy()

            if extra:
                loss = (extra[0] * huber_loss(abs_td_error)).mean()
            else:
                loss = huber_loss(abs_td_error).mean()

            optimizer.zero_grad()
            loss.backward()

            if grad_norm is not None:
                nn.utils.clip_grad_norm_(qnet.parameters(), grad_norm)

            optimizer.step()
            scheduler.step()

            # soft update
            # for tar_net, net in zip(tar_qnet.parameters(), qnet.parameters()):
            #     tar_net.data.copy_(0.001*net.data + 0.999*tar_net.data)
            if prioritized_replay:
                buffer.update_priorities(extra[1], priorities)

        # update target net and log
        if n_iter % target_network_update_freq == 0:
            tar_qnet.load_state_dict(qnet.state_dict())

            print('{} Iter {} {}'.format('=' * 10, n_iter, '=' * 10))
            fps = int(target_network_update_freq / (time.time() - start_ts))
            start_ts = time.time()
            print('FPS {}'.format(fps))

            # if n_iter > learning_starts and n_iter % train_freq == 0:
            #     print('vloss: {:.6f}'.format(loss.item()))
            #     with open(compare_loss, "a") as file:
            #         file.write(str(loss.item()) + '\n')

        # if n_iter > learning_starts and n_iter % 100 == 0:
        #     with open(loss_file, "a") as file:
        #         file.write(str(loss.item()) + '\n')

        if save_interval and n_iter % save_interval == 0:
            torch.save(qnet.state_dict(), os.path.join(save_path, 'DRL_model_for_MAPF_RDE.pth'))

def _generate(device, env, qnet, number_timesteps, exploration_final_eps):
    """ Generate training batch sample """
    if env.curriculum:
        initial_dis = 5
    else:
        initial_dis = env.map_size[0] + env.map_size[1]

    explore_steps = (config.exploration_start_eps - exploration_final_eps) / number_timesteps
    # final_dis = map_size[0] + map_size[1] = 28
    distance_step = (initial_dis - config.final_dis) / number_timesteps
    o = env.reset(initial_dis)
    done = [False for _ in range(env.num_agents)]
    # if use imitation learning
    if env.imitation:
        imitation_ratio = config.imitation_ratio
    else:
        imitation_ratio = 0
    if random.random() < imitation_ratio:
        imitation = True
        imitation_actions = find_path(env)
        while imitation_actions is None:
            o = env.reset(initial_dis)
            imitation_actions = find_path(env)
    else:
        imitation = False

    o = torch.from_numpy(o).to(device)

    epsilon = config.exploration_start_eps
    distance = initial_dis
    for n in range(1, number_timesteps + 1):
        if imitation:
            a = imitation_actions.pop(0)
        else:
            with torch.no_grad():
                ob = o
                q = qnet(ob)
                a = q.argmax(1).cpu().tolist()
                for a_num in range (env.num_agents):
                    if random.random() < epsilon:
                        a[a_num] = np.random.randint(0, config.action_space)

                for i, d in enumerate(done):
                    if d:
                        a[i] = 0

        # take action in env
        o_, r, done, info = env.step(a)
        # if two agent in the same place, code exit.
        test_same_place = env.agents_pos
        for i in range(test_same_place.shape[0]):
            if np.sum(np.all(test_same_place == test_same_place[i], axis=1)) > 1:
                print('same place')
                sys.exit()
        o_ = torch.from_numpy(o_).to(device)
        yield (o[0, :, :, :], a[0], r[0].item(), o_[0, :, :, :], int(done[0]), imitation, info)
        if done[0] == False and env.steps < config.max_steps:
            o = o_
        else:
            o = env.reset(distance)
            done = [False for _ in range(env.num_agents)]
            if env.imitation:
                imitation_ratio = config.imitation_ratio
            else:
                imitation_ratio = 0
            if random.random() < imitation_ratio:
                imitation = True
                imitation_actions = find_path(env)
                while imitation_actions is None:
                    o = env.reset(initial_dis)
                    imitation_actions = find_path(env)
            else:
                imitation = False

            o = torch.from_numpy(o).to(device)

        epsilon -= explore_steps
        distance -= distance_step


def huber_loss(abs_td_error):
    flag = (abs_td_error < 1).float()
    return flag * abs_td_error.pow(2) * 0.5 + (1 - flag) * (abs_td_error - 0.5)

def seed_torch(seed=0):

    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

if __name__ == '__main__':

    print('the training process starts!')
    start_time = time.time()
    parser = argparse.ArgumentParser("Hyperparameter Setting for MAPF")
    parser.add_argument("--seed", type = int, default = 0, help = "set the seed")
    args = parser.parse_args()

    seed_torch(args.seed)
    # [imitation, curriculum, subgoal, punish, oscillation, closer_further]
    setting_map = {'1_models': [True, True, True, True, True, True]}

    env = Environment(setting_map["{}_models".format(1)])
    learn(env, args)

    print('the training process is finished! the total time is:', time.time() - start_time)
