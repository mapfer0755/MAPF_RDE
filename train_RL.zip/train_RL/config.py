# environment setting


background = 'old_env'   # old_env or warehouse

grad_norm = None

#
a_star = False
map_size = (14, 14)
num_agents = 3

#
action_space = 5
obs_dimension = (4,4)# 9x9
max_steps = 150

# reward setting
move_reward = -0.075
stay_on_goal_reward = 0 #没用
stay_off_goal_reward = -0.175
collision_reward = -1
finish_reward = 5   # CAN BE LARGER
oscillation_reward = -0.3


closer_reward = -0.05
further_reward = -0.1

punish_factor = 1.2

# model setting
num_kernels = 128
all_latent_dim = 512

# training setting

n_steps = 5
batch_size = 256
double_q = True
buffer_size = 20000
exploration_start_eps = 1.0
exploration_final_eps = 0.001
train_freq = 8

learning_starts = 3000
save_interval = 100000
target_network_update_freq = 1000*train_freq
gamma = 0.99
prioritized_replay = True
prioritized_replay_alpha = 0.6
prioritized_replay_beta0 = 0.4
dueling = True
imitation_ratio = 0.3

history_steps = 4

# parameteres to build map
start_place = 2
if background == 'old_env':
    step_stride = 4
if background == 'warehouse':
    step_stride = 3

# curriculum learning
final_dis = map_size[0] + map_size[1]
number_timesteps = 1000000

# about test
debug = False
episode_num = 4
show_step = 200

plot_and_show = True

# select data
file_loss = "Loss"
test_map_size = (14,14)
test_agent_num = 8

CBS_MAX_TIME = 5

render = False

straight_r = 0.02
