import config
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.functional import log_softmax
import numpy
import math
import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
class Flatten(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return x.contiguous().view(x.size(0), -1)

class ResBlock(nn.Module):
    def __init__(self, channel):
        super().__init__()

        self.conv1 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(channel)
        # Batch Normalization将数据拉回到均值为0，方差为1的正态分布上(归一化)，一方面使得数据分布一致，另一方面避免梯度消失、梯度爆炸。

        self.conv2 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(channel)

    def forward(self, x):
        identity = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = F.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        out += identity
        out = F.relu(out)
        return out

class Network(nn.Module):
    def __init__(self, subgoal_or_not, punish, setting_of_oscillation, dueling=True, map_size=config.obs_dimension,):
        super().__init__()

        if subgoal_or_not:
            addition_channel = 3
        else:
            addition_channel = 2

        if punish:
            self.punish = True
        else:
            self.punish = False

        if setting_of_oscillation:
            self.setting_of_oscillation = True
        else:
            self.setting_of_oscillation = False


        self.latent2_dim = 24
        if (self.punish or self.setting_of_oscillation):
            self.latent1_dim = 476
            self.latent3_dim = 12
        else:
            self.latent1_dim = 488

        self.encoder = nn.Sequential(
            nn.Conv2d(addition_channel+config.history_steps, config.num_kernels, 3, 1, 1, bias=False),
            nn.BatchNorm2d(config.num_kernels),
            nn.ReLU(True),
            ResBlock(config.num_kernels),
            nn.Conv2d(config.num_kernels, 16, 1, 1, bias=False),
            nn.BatchNorm2d(16),
            nn.ReLU(True),
            Flatten(),
        )

        self.encoder2 = nn.Sequential(
            nn.Linear(4, self.latent2_dim),
            nn.ReLU(True),
            # nn.Linear(self.latent2_dim,self.latent2_dim),
            # nn.ReLU(True),
        )

        if self.punish and not self.setting_of_oscillation:
            self.encoder3 = nn.Sequential(
                nn.Linear(1, self.latent3_dim),
                nn.ReLU(True),
                # nn.Linear(self.latent3_dim,self.latent3_dim),
                # nn.ReLU(True),
            )

        if not self.punish and self.setting_of_oscillation:
            self.encoder3 = nn.Sequential(
                nn.Linear(1, self.latent3_dim),
                nn.ReLU(True),
                # nn.Linear(self.latent3_dim,self.latent3_dim),
                # nn.ReLU(True),
            )

        if self.punish and self.setting_of_oscillation:
            self.encoder3 = nn.Sequential(
                nn.Linear(2, self.latent3_dim),
                nn.ReLU(True),
                # nn.Linear(self.latent3_dim,self.latent3_dim),
                # nn.ReLU(True),
            )




        self.linear = nn.Sequential(
            nn.Linear(16*(2*config.obs_dimension[0]+1)*(2*config.obs_dimension[1]+1), self.latent1_dim),
            nn.ReLU(True),
            nn.Linear(self.latent1_dim, self.latent1_dim),
            nn.ReLU(True),
        )

        self.linear2 = nn.Sequential(
            # 定义 config.all_latent_dim = 512
            nn.Linear(config.all_latent_dim,config.all_latent_dim),
            nn.ReLU(True),
            nn.Linear(config.all_latent_dim, config.all_latent_dim),
            nn.ReLU(True),
        )

        self.adv = nn.Linear(config.all_latent_dim, config.action_space)

        self.state = nn.Linear(config.all_latent_dim, 1)

        for _, m in self.named_modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Conv2d):
                torch.nn.init.kaiming_uniform_(m.weight, mode='fan_in', nonlinearity='relu')


    def forward(self, x):
        with torch.no_grad():
            x1 = x[:,0:-1,:,:]
            # x1 = torch.LongTensor(x1)
            # x1 = x1.type(torch.FloatTensor).to('cuda:0')
            x1 = x1.type(torch.FloatTensor).to(device)
            # x2
            x2 = []
            for i in range(x.size()[0]):
                x2.append((x[i,-1,0,0],x[i,-1,0,1], x[i,-1,0,2],x[i,-1,0,3]))
            x2 = numpy.array(x2).astype(float)
            x2 = torch.from_numpy(x2)
            # x2 = x2.type(torch.FloatTensor).to('cuda:0')
            x2 = x2.type(torch.FloatTensor).to(device)
            # x3
            if self.punish and not self.setting_of_oscillation:
                x3 = []
                for i in range(x.size()[0]):
                    x3.append(x[i, -1, 0, 4])
                x3 = numpy.array(x3).astype(float)
                x3 = torch.from_numpy(x3)
                x3 = x3.type(torch.FloatTensor).to(device)

            if not self.punish and self.setting_of_oscillation:
                x3 = []
                for i in range(x.size()[0]):
                    x3.append(x[i, -1, 0, 5])
                x3 = numpy.array(x3).astype(float)
                x3 = torch.from_numpy(x3)
                x3 = x3.type(torch.FloatTensor).to(device)

            if self.punish and self.setting_of_oscillation:
                x3 = []
                for i in range(x.size()[0]):
                    x3.append((x[i, -1, 0, 4],x[i, -1, 0, 5]))
                x3 = numpy.array(x3).astype(float)
                x3 = torch.from_numpy(x3)
                x3 = x3.type(torch.FloatTensor).to(device)

        latent1 = self.encoder(x1)

        latent1 = self.linear(latent1)
        latent2 = self.encoder2(x2)

        if (self.punish and not self.setting_of_oscillation) or (not self.punish and self.setting_of_oscillation):
            x3 = torch.unsqueeze(x3, dim=1)
            latent3 = self.encoder3(x3)

        if self.punish and self.setting_of_oscillation:
            latent3 = self.encoder3(x3)

        latent = torch.cat((latent1,latent2),dim=1)
        if self.punish or self.setting_of_oscillation:
            latent = torch.cat((latent,latent3), dim=1)

        latent = self.linear2(latent)
        adv_val = self.adv(latent)
        s_val = self.state(latent)
        q_val = s_val + adv_val - adv_val.mean(1, keepdim=True)

        return q_val