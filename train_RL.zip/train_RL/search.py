import time as timer
import heapq
import random
import numpy as np
import config
import copy
import os
from visualize import Animation
action_list = np.array([[0, 0],[-1, 0],[1, 0],[0, -1],[0, 1]], dtype=np.int8)

# import matplotlib.pyplot as plt
# plt.switch_backend('agg')

def move(loc, dir):
    directions = [(0, -1), (1, 0), (0, 1), (-1, 0), (0, 0)]
    return loc[0] + directions[dir][0], loc[1] + directions[dir][1]


def get_sum_of_cost(paths):
    rst = 0
    for path in paths:
        rst += len(path) - 1
    return rst

def get_make_span(paths):
    make_span = 0
    for path in paths:
        if make_span < len(path)-1:
            make_span = len(path)
    return make_span

def compute_heuristics(my_map, goal):
    # Use Dijkstra to build a shortest-path tree rooted at the goal location
    open_list = []
    closed_list = dict()
    root = {'loc': goal, 'cost': 0}
    heapq.heappush(open_list, (root['cost'], goal, root))
    closed_list[goal] = root
    while len(open_list) > 0:
        (cost, loc, curr) = heapq.heappop(open_list)
        for dir in range(4):
            next_loc = move(loc, dir)
            next_cost = cost + 1
            if next_loc[0]<0 or next_loc[0]>=len(my_map) or next_loc[1]<0 or next_loc[1]>=len(my_map[0]) or  my_map[next_loc[0]][next_loc[1]]:
                continue
            next = {'loc': next_loc, 'cost': next_cost}
            if next_loc in closed_list:
                existing_node = closed_list[next_loc]
                if existing_node['cost'] > next_cost:
                    closed_list[next_loc] = next
                    # open_list.delete((existing_node['cost'], existing_node['loc'], existing_node))
                    heapq.heappush(open_list, (next_cost, next_loc, next))
            else:
                closed_list[next_loc] = next
                heapq.heappush(open_list, (next_cost, next_loc, next))

    # build the heuristics table
    h_values = dict()
    for loc, node in closed_list.items():
        h_values[loc] = node['cost']
    return h_values


def build_constraint_table(constraints, agent):
    positive = []  # to collect positive constraints
    negative = []  # to collect negative constraints
    max_timestep = -1  # the maximum timestep in these constraints
    #  collect constraints that are related to this agent
    for constraint in constraints:
        if constraint['positive']:  # positive constraint is effective for everyone
            if constraint['agent'] == agent:
                positive.append(constraint)
            else:
                negative.append(constraint)
            max_timestep = max(max_timestep, constraint['timestep'])
        elif constraint['agent'] == agent:  # negative constraint is effective for only one agent
            negative.append(constraint)
            max_timestep = max(max_timestep, constraint['timestep'])

    constraint_table = [[] for _ in range(max_timestep + 1)]
    for constraint in positive:
        if len(constraint['loc']) == 1:  # positive vertex constraint
            constraint_table[constraint['timestep']].append({'loc': constraint['loc'], 'positive': True})
        else:  # positive edge constraint
            constraint_table[constraint['timestep'] - 1].append({'loc': [constraint['loc'][0]], 'positive': True})
            constraint_table[constraint['timestep']].append({'loc': [constraint['loc'][1]], 'positive': True})

    for constraint in negative:
        if len(constraint['loc']) == 1:  # vertex constraint
            constraint_table[constraint['timestep']].append({'loc': constraint['loc'], 'positive': False})
        elif constraint['positive']:  # positive edge constraint for other agents
            constraint_table[constraint['timestep'] - 1].append({'loc': [constraint['loc'][0]], 'positive': False})
            constraint_table[constraint['timestep']].append({'loc': [constraint['loc'][1]], 'positive': False})
            constraint_table[constraint['timestep']].append(
                {'loc': [constraint['loc'][1], constraint['loc'][0]], 'positive': False})
        else:  # negative edge constraint
            constraint_table[constraint['timestep']].append({'loc': constraint['loc'], 'positive': False})

    return constraint_table


def get_location(path, time):
    if time < 0:
        return path[0]
    elif time < len(path):
        return path[time]
    else:
        return path[-1]  # wait at the goal location

def paths_violate_constraint(constraint, paths):
    assert constraint['positive'] is True
    rst = []
    for i in range(len(paths)):
        if i == constraint['agent']:
            continue
        curr = get_location(paths[i], constraint['timestep'])
        prev = get_location(paths[i], constraint['timestep'] - 1)
        if len(constraint['loc']) == 1:  # vertex constraint
            if constraint['loc'][0] == curr:
                rst.append(i)
        else:  # edge constraint
            if constraint['loc'][0] == prev or constraint['loc'][1] == curr \
                    or constraint['loc'] == [curr, prev]:
                rst.append(i)
    return rst


def get_path(goal_node):
    path = []
    curr = goal_node
    while curr is not None:
        path.append(curr['loc'])
        curr = curr['parent']
    path.reverse()
    return path


def is_constrained(curr_loc, next_loc, next_time, constraint_table):
    if len(constraint_table) <= next_time:
        return False


    for constraint in constraint_table[next_time]:
        if constraint['positive']:  # positive constraint
            if constraint['loc'][0] != next_loc:
                return True
        else:  # negative constraint
            if len(constraint['loc']) == 1:  # vertex constraint
                if constraint['loc'][0] == next_loc:
                    return True
            else:  # edge constraint
                if constraint['loc'] == [curr_loc, next_loc]:
                    return True

    return False

def get_num_collisions(curr_loc, next_loc, next_time, paths):
    rst = 0
    for path in paths:
        if len(path) <= next_time:
            continue
        if path[next_time] == next_loc:
            rst += 1  # vertex conflict
        if next_time == 0:
            continue
        if path[next_time - 1] == next_loc and path[next_time] == curr_loc:
            rst += 1  # edge conflict
    return rst


def push_node(open_list, node):
    heapq.heappush(open_list, (node['g_val'] + node['h_val'], node['collisions'], node['h_val'], node['loc'], node))


def pop_node(open_list):
    _, _, _, _, curr = heapq.heappop(open_list)
    return curr


def compare_nodes(n1, n2):
    """Return true is n1 is better than n2."""
    if n1['g_val'] + n1['h_val'] == n2['g_val'] + n2['h_val']:
        return n1['collisions'] < n2['collisions']
    return n1['g_val'] + n1['h_val'] < n2['g_val'] + n2['h_val']


def a_star(my_map, start_loc, goal_loc, h_values, agent, constraints, paths):
    """ my_map      - binary obstacle map
        start_loc   - start position
        goal_loc    - goal position
        agent       - the agent that is being re-planned
        constraints - constraints defining where robot should or cannot go at each timestep
        paths       - paths of other robots to try to avoid if possible,
                      but will not incur extra cost to do so
    """

    constraint_table = build_constraint_table(constraints, agent)
    open_list = []
    closed_list = dict()
    earliest_goal_timestep = 0
    h_value = h_values[start_loc]
    root = {'loc': start_loc, 'g_val': 0, 'h_val': h_value, 'collisions': 0, 'timestep': 0, 'parent': None}
    push_node(open_list, root)
    closed_list[(root['loc'], root['timestep'])] = root
    while len(open_list) > 0:
        curr = pop_node(open_list)
        if curr['loc'] == goal_loc and curr['timestep'] >= earliest_goal_timestep:
            found = True
            if curr['timestep'] + 1 < len(constraint_table):
                for t in range(curr['timestep'] + 1, len(constraint_table)):
                    if is_constrained(goal_loc, goal_loc, t, constraint_table):
                        found = False
                        earliest_goal_timestep = t + 1
                        break
            if found:
                return get_path(curr)
        for dir in range(5):
            next_loc = move(curr['loc'], dir)

            if next_loc[0]<0 or next_loc[0]>=len(my_map) or next_loc[1]<0 or next_loc[1]>=len(my_map[0]):
                continue

            if my_map[next_loc[0]][next_loc[1]] or is_constrained(curr['loc'], next_loc, curr['timestep'] + 1,
                                                                  constraint_table):
                continue
            next_collisions = curr['collisions'] + get_num_collisions(
                curr['loc'], next_loc, curr['timestep'] + 1, paths)
            next = {'loc': next_loc, 'g_val': curr['g_val'] + 1,
                    'h_val': h_values[next_loc], 'collisions': next_collisions,
                    'timestep': curr['timestep'] + 1, 'parent': curr}
            if (next['loc'], next['timestep']) in closed_list:
                existing_node = closed_list[(next['loc'], next['timestep'])]
                if compare_nodes(next, existing_node):
                    closed_list[(next['loc'], next['timestep'])] = next
                    # delete_node(open_list, existing_node)
                    push_node(open_list, next)
            else:
                closed_list[(next['loc'], next['timestep'])] = next
                push_node(open_list, next)

    return None  # Failed to find solutions

def detect_conflict(path1, path2):
    ##############################
    # Task 3.1: Return the first conflict that occurs between two robot paths (or None if there is no conflict)
    #           There are two types of conflicts: vertex conflict and edge conflict.
    #           A vertex conflict occurs if both robots occupy the same location at the same timestep
    #           An edge conflict occurs if the robots swap their location at the same timestep.
    #           You should use "get_location(path, t)" to get the location of a robot at time t.

    for t in range(max(len(path1), len(path2))):
        c1 = get_location(path1, t)
        c2 = get_location(path2, t)
        if c1 == c2:
            return [c1, t]
        else:
            p1 = get_location(path1, t-1)
            p2 = get_location(path2, t-1)
            if c1 == p2 and c2 == p1:
                return [p1, c1, t]
    return None

def detect_conflicts(paths):
    ##############################
    # Task 3.1: Return a list of first conflicts between all robot pairs.
    #           A conflict can be represented as dictionary that contains the id of the two robots, the vertex or edge
    #           causing the conflict, and the timestep at which the conflict occurred.
    #           You should use your detect_conflict function to find a conflict between two robots.

    conflicts = []
    for i in range(len(paths) - 1):
        for j in range(i + 1, len(paths)):
            conflict = detect_conflict(paths[i], paths[j])
            if conflict is not None:
                conflicts.append({'a1': i,
                                  'a2': j,
                                  'loc': conflict[: -1],
                                  'timestep': conflict[-1]})
    return conflicts

def standard_splitting(conflict):
    ##############################
    # Task 3.2: Return a list of (two) constraints to resolve the given conflict
    #           Vertex conflict: the first constraint prevents the first agent to be at the specified location at the
    #                            specified timestep, and the second constraint prevents the second agent to be at the
    #                            specified location at the specified timestep.
    #           Edge conflict: the first constraint prevents the first agent to traverse the specified edge at the
    #                          specified timestep, and the second constraint prevents the second agent to traverse the
    #                          specified edge at the specified timestep

    constrain1 = {'agent': conflict['a1'],
                  'loc': conflict['loc'],
                  'timestep': conflict['timestep'],
                  'positive': False}
    loc = list(conflict['loc'])
    loc.reverse()
    constrain2 = {'agent': conflict['a2'],
                  'loc': loc,
                  'timestep': conflict['timestep'],
                  'positive': False}
    return [constrain1, constrain2]

def disjoint_splitting(conflict):
    ##############################
    # Task 4.1: Return a list of (two) constraints to resolve the given conflict
    #           Vertex conflict: the first constraint enforces one agent to be at the specified location at the
    #                            specified timestep, and the second constraint prevents the same agent to be at the
    #                            same location at the timestep.
    #           Edge conflict: the first constraint enforces one agent to traverse the specified edge at the
    #                          specified timestep, and the second constraint prevents the same agent to traverse the
    #                          specified edge at the specified timestep
    #           Choose the agent randomly

    i = random.randint(0, 1)
    if i == 0:
        constrain1 = {'agent': conflict['a1'],
                      'loc': conflict['loc'],
                      'timestep': conflict['timestep'],
                      'positive': True}
        constrain2 = {'agent': conflict['a1'],
                      'loc': conflict['loc'],
                      'timestep': conflict['timestep'],
                      'positive': False}
    else:
        loc = list(conflict['loc'])
        loc.reverse()

        constrain1 = {'agent': conflict['a2'],
                      'loc': loc,
                      'timestep': conflict['timestep'],
                      'positive': True}
        constrain2 = {'agent': conflict['a2'],
                      'loc': loc,
                      'timestep': conflict['timestep'],
                      'positive': False}

    return [constrain1, constrain2]

class CBSSolver(object):
    """The high-level search of CBS."""

    def __init__(self, my_map, starts, goals):
        """my_map   - list of lists specifying obstacle positions
        starts      - [(x1, y1), (x2, y2), ...] list of start locations
        goals       - [(x1, y1), (x2, y2), ...] list of goal locations
        """

        self.my_map = my_map
        self.starts = starts
        self.goals = goals
        self.num_of_agents = len(goals)

        self.num_of_generated = 0
        self.num_of_expanded = 0

        self.open_list = []

        # compute heuristics for the low-level search
        self.heuristics = []
        for goal in self.goals:
            self.heuristics.append(compute_heuristics(my_map, goal))

    def push_node(self, node):
        heapq.heappush(self.open_list, (
        node['cost'], len(node['conflicts']), self.num_of_generated, node))
        # print("Generate node {}".format(self.num_of_generated))
        self.num_of_generated += 1

    def pop_node(self):
        _, _, id, node = heapq.heappop(self.open_list)
        # print("Expand node {}".format(id))
        self.num_of_expanded += 1
        return node

    def find_solution(self, disjoint=True, time_limit=60):
        """ Finds paths for all agents from their start locations to their goal locations

        disjoint    - use disjoint splitting or not
        time_limit  - maximum amount of execution time allowed
        """

        start_time = timer.time()

        # Generate the root node
        # constraints   - list of constraints
        # paths         - list of paths, one for each agent
        #               [[(x11, y11), (x12, y12), ...], [(x21, y21), (x22, y22), ...], ...]
        # conflicts     - list of conflicts in paths
        root = {'cost': 0,
                'constraints': [],
                'paths': [],
                'conflicts': [],
                'parent': None}
        for i in range(self.num_of_agents):  # Find initial path for each agent
            if config.background == 'old_env':
                temp_map = copy.deepcopy(self.my_map)
                temp_map[self.goals[i]] = 0
                path = a_star(temp_map, self.starts[i], self.goals[i],
                              self.heuristics[i], i, root['constraints'], root['paths'])

            if config.background == 'warehouse':
                path = a_star(self.my_map, self.starts[i], self.goals[i],
                              self.heuristics[i], i, root['constraints'],
                              root['paths'])

            if path is None:
                raise BaseException('No solutions')
            root['paths'].append(path)

        root['cost'] = get_sum_of_cost(root['paths'])
        root['conflicts'] = detect_conflicts(root['paths'])
        self.push_node(root)

        # # Task 3.1: Testing
        # print(root['conflicts'])
        #
        # # Task 3.2: Testing
        # for conflict in root['conflicts']:
        #     print(standard_splitting(conflict))

        ##############################
        # Task 3.3: High-Level Search
        #           Repeat the following as long as the open list is not empty:
        #             1. Get the next node from the open list (you can use self.pop_node()
        #             2. If this node has no conflict, return solution
        #             3. Otherwise, choose the first conflict and convert to a list of constraints (using your
        #                standard_splitting function). Add a new child node to your open list for each constraint
        #           Ensure to create a copy of any objects that your child nodes might inherit

        while len(self.open_list) > 0:
            node = self.pop_node()
            if node['conflicts'] == []:
                # self.print_results(node)
                return node['paths']

            conflict = random.choice(node['conflicts'])
            # print("Choose a conflict between {} and {} at location {} at timestep {}".format(
            #     conflict['a1'], conflict['a2'], conflict['loc'], conflict['timestep']))

            new_constraints = standard_splitting(conflict)
            # new_constraints = disjoint_splitting(conflict)

            if timer.time() - start_time > config.CBS_MAX_TIME:
                return None

            for constraint in new_constraints:
                # i = constraint['agent']
                # print("Negative constraint on agent {} at location {} at timestep {}".format(
                #     constraint['agent'], constraint['loc'], constraint['timestep']))
                constraints = list(node['constraints'])
                constraints.append(constraint)

                paths = list(node['paths'])
                # paths[i] = a_star(self.my_map, self.starts[i], self.goals[i], self.heuristics[i],
                #                    i, constraints, paths)

                replan = []
                if constraint['positive']:
                    replan = paths_violate_constraint(constraint, paths)
                else:
                    replan.append(constraint['agent'])
                # child_node = {'cost': get_sum_of_cost(paths),
                #              'constraints':constraints,
                #              'paths': paths,
                #              'conflicts': detect_conflicts(paths),
                #              'parent': node}
                # self.push_node(child_node)

                prune = False
                for i in replan:
                    if config.background == 'old_env':
                        temp_map = copy.deepcopy(self.my_map)
                        temp_map[self.goals[i]] = 0
                        paths[i] = a_star(temp_map, self.starts[i],
                                          self.goals[i], self.heuristics[i],
                                          i, constraints, paths)

                    if config.background == 'warehouse':
                        paths[i] = a_star(self.my_map, self.starts[i],
                                          self.goals[i], self.heuristics[i],
                                          i, constraints, paths)

                    if paths[i] is None:
                        prune = True
                        break

                if not prune:
                    child_node = {'cost': get_sum_of_cost(paths),
                                  'constraints': constraints,
                                  'paths': paths,
                                  'conflicts': detect_conflicts(paths),
                                  'parent': node}
                    self.push_node(child_node)

def find_path(env,mode = 'training' ):

    map = np.copy(env.map)
    temp_agents_pos = np.copy(env.agents_pos)
    agents_pos= []
    for pos in temp_agents_pos:
        agents_pos.append(tuple(pos))
    temp_goals_pos = np.copy(env.goals_pos)
    goals_pos = []
    for pos in temp_goals_pos:
        goals_pos.append(tuple(pos))

    #
    # log = './result/map{}_agent{}/log{}_{}'.format(map_size, number_of_agent,
    #                                                map_size, number_of_agent)
    # if not os.path.exists(log):
    #     os.system(r"touch {}".format(log))

    if mode == 'testing':
        write_file_CBS = './result/map{}_agent{}/CBS_time{}_{}'\
            .format(map.shape[0], len(agents_pos), map.shape[0], len(agents_pos))
        if not os.path.exists(write_file_CBS):
            os.system(r"touch {}".format(write_file_CBS))
        start = timer.time()
        solver = CBSSolver(map, agents_pos, goals_pos)
        paths = solver.find_solution(start_time=start)
        if paths == None:
            end = start + config.CBS_MAX_TIME    # 超时的话，记为CBS_MAX_TIME
        else:
            end = timer.time()
        with open(write_file_CBS, "a") as file:
            file.write(str(end - start) + '\n')
    else:
        start = timer.time()
        solver = CBSSolver(map, agents_pos, goals_pos)
        paths = solver.find_solution()
        # print(1)
        # animation = Animation(map, agents_pos,goals_pos,paths)
        # animation.show()
        # animation.close()
    if paths is None:
        return None

    max_len = max([len(path) for path in paths])

    # [-1] 读取倒数第一个元素,
    # 将每个path路径都补齐，变成一样长
    for path in paths:
        while len(path) < max_len:
            path.append(path[-1])


    actions = []

    for step in range(1, max_len):
        step_action = []

        for i in range(env.num_agents):
            direction = np.asarray(paths[i][step]) - np.asarray(paths[i][step-1])

            if np.array_equal(direction, action_list[0]):
                step_action.append(0)
            elif np.array_equal(direction, action_list[1]):
                step_action.append(1)
            elif np.array_equal(direction, action_list[2]):
                step_action.append(2)
            elif np.array_equal(direction, action_list[3]):
                step_action.append(3)
            elif np.array_equal(direction, action_list[4]):
                step_action.append(4)
            else:
                raise RuntimeError('no action match')

        if env.num_agents == 1:
            actions.append(step_action[0])
        else:
            actions.append(step_action)

    return actions 