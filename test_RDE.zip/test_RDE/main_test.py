import string
import numpy as np
import torch
import pickle
import os
# import matplotlib.pyplot as plt
import time
import random
import argparse
import sys

from model import Network
import config
from test_environment import Environment, action_list

def seed_torch(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def make_file(file_name):
    if not os.path.exists(file_name):
        os.system(r"touch {}".format(file_name))
    with open(file_name, 'w') as f:
        f.truncate()

def test_model(args, result_directory, model_name,test_name, test_num,env,network, device):
    # network = Network(config.dueling)
    state_dict = torch.load(model_name, map_location=device)
    network.load_state_dict(state_dict)
    network.eval()
    network = network.to(device)
    test_cases = [test_name]

    for test_case in test_cases:
        l = len(test_cases) # l = 1
        with open(test_case, 'rb') as f:
            tests = pickle.load(f)

        fail = 0
        SOC_of_D3QN_MAPF = []
        turn_of_D3QN_MAPF = []
        PATH_of_all_tests = []
        index_success = []
        sum_turn_cnt = 0

        for i in range(test_num):
            reached_goals_function = []
            reached_agents = []
            reached_goals = 0
            turn_cnt = 0
            sum_of_cost = 0
            start_time = time.time()
            pre_action = [0 for _ in range(env.num_agents)]
            # load 之后环境信息重置 env 信息，所以在 “test_environment.py"中对 env 的地图类型不需要重置
            env.load(tests['maps'][i], tests['agents'][i], tests['goals'][i])
            done = [False for _ in range(env.num_agents)]
            obs = env.observe()

            while False in done and env.steps < config.max_steps:
                # print(1)
                start_time = time.time()
                obs = torch.from_numpy(obs).float()
                # calculate the network runtime
                with torch.no_grad():

                    q_vals = network(obs)
                q_vals[0][0]=0
                action = torch.argmax(q_vals, 1).tolist()
                if env.dhm:
                    for index in range(env.num_agents):
                        if done[index] == False:
                            if np.all(obs[index,0].numpy() == 1) and not done[index]:
                                closer_action = []
                                if obs[index, -1, 0, 0] == 1:
                                    closer_action.append(1)
                                    # action[index] = 1
                                if obs[index, -1, 0, 1] == 1:
                                    closer_action.append(2)
                                    # action[index] = 2
                                if obs[index, -1, 0, 2] == 1:
                                    closer_action.append(3)
                                    # action[index] = 3
                                if obs[index, -1, 0, 3] == 1:
                                    closer_action.append(4)
                                    # action[index] = 4
                                if closer_action:
                                    for i in range(len(closer_action)):
                                        if closer_action[i] == pre_action[index]:
                                            action[index] = closer_action[i]
                                            break
                                        else:
                                            action[index] = random.choice(closer_action)

                for j in range(env.num_agents):
                    if done[j]:
                        action[j] = 0
                    pre_action[j] = action[j]
                obs, reward, done, _ = env.step(action)
                for j in range(env.num_agents):
                    if done[j] and j not in reached_agents:
                            reached_agents.append(j)
                            reached_goals += 1
                reached_goals_function.append(reached_goals)

            episode_time = time.time() - start_time
            # the timestep of reached goals function is 150
            if env.steps == config.max_steps:
                makespan = 0
            else:
                makespan = env.steps
                for k in range(env.steps, config.max_steps):
                    reached_goals_function.append(reached_goals)

            # 计算 sum-of-cost and turn_cnt
            if np.array_equal(env.agents_pos, env.goals_pos):
                agents_path = [[] for _ in range (env.num_agents)]
                finish_id = [0 for _ in range (env.num_agents)]
                for episode in range(env.steps+1):
                    for id in range(env.num_agents):
                        if not finish_id[id]:
                            agents_path[id].append(env.history[episode][id].tolist())
                            if np.array_equal(env.history[episode][id], env.goals_pos[id]):
                                finish_id[id] = 1
                for agent_num in range (env.num_agents):
                    sum_of_cost += len(agents_path[agent_num])-1

                    n = len(agents_path[agent_num])
                    if n > 2:  # 转弯
                        for step in range(2, n):
                            delta_x1 = agents_path[agent_num][step][0] - agents_path[agent_num][step - 1][0]
                            delta_y1 = agents_path[agent_num][step][1] - agents_path[agent_num][step - 1][1]
                            delta_x2 = agents_path[agent_num][step - 1][0] - agents_path[agent_num][step - 2][0]
                            delta_y2 = agents_path[agent_num][step - 1][1] - agents_path[agent_num][step - 2][1]
                            if (delta_x1 == delta_x2) and (delta_y1 == delta_y2) and not (
                                    agents_path[agent_num][step] == agents_path[agent_num][step - 1]):
                                turn_cnt += 1

                PATH_of_all_tests.append(agents_path)
                # print(sum_of_cost, episode_time)

                SOC_of_D3QN_MAPF.append(sum_of_cost)

                index_success.append(1)

            else:
                fail += 1

                agents_path = [[] for _ in range(env.num_agents)]
                finish_id = [0 for _ in range(env.num_agents)]
                for episode in range(config.max_steps + 1):
                    for id in range(env.num_agents):
                        if not finish_id[id]:
                            agents_path[id].append(env.history[episode][id].tolist())
                            if np.array_equal(env.history[episode][id], env.goals_pos[id]):
                                finish_id[id] = 1
                for agent_num in range(env.num_agents):
                    sum_of_cost += len(agents_path[agent_num]) - 1

                    n = len(agents_path[agent_num])
                    if n > 2:  # 转弯
                        for step in range(2, n):
                            delta_x1 = agents_path[agent_num][step][0] - agents_path[agent_num][step - 1][0]
                            delta_y1 = agents_path[agent_num][step][1] - agents_path[agent_num][step - 1][1]
                            delta_x2 = agents_path[agent_num][step - 1][0] - agents_path[agent_num][step - 2][0]
                            delta_y2 = agents_path[agent_num][step - 1][1] - agents_path[agent_num][step - 2][1]
                            if (delta_x1 == delta_x2) and (delta_y1 == delta_y2) and not (
                                    agents_path[agent_num][step] == agents_path[agent_num][step - 1]):
                                turn_cnt += 1

                PATH_of_all_tests.append(agents_path) # 添加 0 ，可能对失败案例的观察失效
                SOC_of_D3QN_MAPF.append(sum_of_cost)
                index_success.append(0)
            sum_turn_cnt += turn_cnt

            #---------------------------------------------------#
            sys.stdout.write("\r the test number is: %d" % (i + 1))
            sys.stdout.flush()
            #---------------------------------------------------#

        if fail != test_num:
            success_ratio = 1 - fail/test_num
        else:
            success_ratio = 0

        print('  mapsize: {} agentnum: {} success_ratio: {:.1f}%'.format(env.map_size[0], env.num_agents, success_ratio * 100))

def write_data_to_file(result_dir, mapsize, num_agents, test_num, parameters, parameters_name):
    with open(result_dir + '/{}_map_{}_agent_{}_testnum_{}.pk'.format(parameters_name,
            mapsize, num_agents, test_num), 'wb') as f:
        pickle.dump(parameters, f)
    file = open(
        result_dir + "/{}_map_{}_agent_{}_testnum_{}.txt".format(parameters_name, mapsize, num_agents, test_num), 'a')
    file.write(str(parameters) + '\n')
    file.close()


# [imitation, curriculum, subgoal, punish, oscillation, closer_further, distance heat map, os_random_pick]
setting_map = {'1_models':[True, True,  True,  True,  True,  True, True,  True]}

def func_each_episode_MS(each_episode_MS, mapsize, num_of_agent, directory):
    directory = directory+'/each_step'
    if not os.path.exists(directory):
        os.system(r"mkdir {}".format(directory))
    file_name = directory + '/' + each_episode_MS + '_{}'.format(mapsize)+'_{}'.format(num_of_agent)
    if not os.path.exists(file_name):
        os.system(r"touch {}".format(file_name))
    with open(file_name, 'w') as f:
        f.truncate()
    return file_name

def global_test(file_folder, args, index):

    device = config.device
    if device == "cpu":
        os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
    # mpl.use('TkAgg')

    types_map = ['narrow_aisle_warehouse_2_2'] # 'wide_aisle_warehouse'

    for type_map in types_map:
        print('map_type: {} env_num: {}'.format(type_map, file_folder))
        for map_size in [34, 82]: # 100
            if map_size < 100:
                test_num = 1000
            else:
                test_num = 50
            for num_agent in [10, 30, 50, 70, 90]: # 500

                test_directory = '../instances_oneshot/{}/instance_of_map_{}'.format(type_map, map_size)
                test_file = test_directory + '/test{}_{}_{}.pkl'.format(map_size, num_agent, test_num)

                env = Environment(setting_map[file_folder], map_size, num_agent, type_map)
                net_model = './net_model_D3QN_MAPF' + '/DRL_model_for_MAPF_RDE.pth'
                result_directory = '../results/one_shot/{}/MAPF_D3QN_{}'.format(type_map, file_folder)

                if not os.path.exists(result_directory):
                    os.system(r"mkdir {}".format(result_directory))
                network = Network(device=device, subgoal_or_not=env.subgoal_or_not,
                                  punish=env.punish,
                                  setting_of_oscillation=env.setting_of_oscillation,
                                  dueling=config.dueling)
                test_model(args, result_directory, net_model, test_file, test_num, env, network, device)

if __name__ == "__main__":

    parser = argparse.ArgumentParser("Hyperparameter Setting for MAPF")
    parser.add_argument("--seed", type=int, default=0, help="set the seed")
    args = parser.parse_args()
    seed_torch(args.seed)

    file_folder_index = [1]
    for index in file_folder_index:
        file_folder = '{}_models'.format(index)
        global_test(file_folder, args, index)
