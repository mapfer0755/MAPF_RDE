import numpy as np
import copy
import matplotlib.pyplot as plt
from matplotlib import colors
from numba import jit
import random
import time
import heapq
from typing import List

import config

action_list = np.array([[0, 0], [-1, 0], [1, 0], [0, -1], [0, 1]],
                       dtype=np.int8)

color_map = np.array([[255, 255, 255],  # white
                      [190, 190, 190],  # gray
                      [0, 191, 255],  # blue
                      [255, 165, 0],  # orange
                      [159, 250, 154],
                      [183, 184, 104],
                      [76, 140, 254],
                      [16, 20, 54],
                      [80, 200, 104],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                     [9, 201, 20],
                     [140, 20, 60],
                     [70, 201, 24],
                     [180, 210, 24],
                     [89, 150, 90],
                     [180, 210, 204],
                     [140, 120, 4],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                     [9, 201, 20],
                     [140, 20, 60],
                     [70, 201, 24],
                     [180, 210, 24],
                     [89, 150, 90],
                     [180, 210, 204],
                     [140, 120, 4],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                     [9, 201, 20],
                     [140, 20, 60],
                     [70, 201, 24],
                     [180, 210, 24],
                     [89, 150, 90],
                     [180, 210, 204],
                     [140, 120, 4],
                      [89, 150, 90],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                     [9, 201, 20],
                     [140, 20, 60],
                     [70, 201, 24],
                     [180, 210, 24],
                     [89, 150, 90],
                     [180, 210, 204],
                     [140, 120, 4],
                      [89, 150, 90],
                      [255, 165, 0],  # orange
                      [159, 250, 154],
                      [183, 184, 104],
                      [76, 140, 254],
                      [16, 20, 54],
                      [80, 200, 104],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                      [89, 150, 90],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                      [9, 201, 20],
                      [140, 20, 60],
                      [70, 201, 24],
                      [180, 210, 24],
                      [89, 150, 90],
                      [180, 210, 204],
                      [140, 120, 4],
                      [89, 150, 90]])  # green


def move(loc, dir):
    directions = [(0, -1), (1, 0), (0, 1), (-1, 0)]
    return loc[0] + directions[dir][0], loc[1] + directions[dir][1]


class Environment:
    def __init__(self, setting, map_size, num_agents, map_type):
        '''
        self.map:
            0 = empty
            1 = obstacle
        '''
        # [imitation, curriculum, subgoal, punish, oscillation, closer_further
        # post_process, a_star]
        self.imitation = setting[0]
        self.curriculum = setting[1]
        self.subgoal_or_not = setting[2]
        self.punish = setting[3]
        self.setting_of_oscillation = setting[4]
        self.closer_further = setting[5]
        self.dhm = setting[6]
        self.os_random_pick = setting[7]

        self.closer_reward = config.closer_reward
        if self.closer_further:
            self.further_reward = config.further_reward
        else:
            self.further_reward = self.closer_reward

        self.random_agents = True
        self.num_agents = num_agents  #  Variable(number_of_agent) is in the "test" file

        self.map_size = tuple((map_size,map_size))
        self.obs_dim = config.obs_dimension

        self.background = map_type

        if self.background == 'wide_aisle_warehouse':
            self.map = np.zeros(self.map_size).astype(np.float32)
            for i in range(config.start_place, self.map_size[0], config.step_stride):
                for j in range(config.start_place, self.map_size[0], config.step_stride):
                    self.map[i:i + 2, j:j + 2] = 1

        if self.background == 'narrow_aisle_warehouse_2_2':
            self.map = np.zeros(self.map_size).astype(np.float32)
            start_place = 1
            step_stride_row = 3
            step_stride_column = 3
            for i in range(start_place, self.map_size[0], step_stride_column):
                for j in range(start_place, self.map_size[0], step_stride_row):
                    self.map[i:i + 2, j:j + 2] = 1

        if self.background == 'narrow_aisle_warehouse_3_2':
            self.map = np.zeros(self.map_size).astype(np.float32)
            start_place = 1
            step_stride_row = 3
            step_stride_column = 4
            for i in range(start_place, self.map_size[0], step_stride_column):
                for j in range(start_place, self.map_size[0], step_stride_row):
                    self.map[i:i + 3, j:j + 2] = 1

        # choose start and goal place
        count = 0

        self.agents_pos, self.goals_pos = [], []
        while (count < self.num_agents):
            # temp_place = [start,goal]
            temp_start = (np.random.randint(self.map_size[0]),
                          np.random.randint(self.map_size[0]))
            temp_end = (np.random.randint(1, self.map_size[0]),
                        np.random.randint(1, self.map_size[0]))
            if temp_start not in self.agents_pos and self.map[
                temp_start[0], temp_start[
                    1]] == 0 and temp_end not in self.goals_pos and self.map[
                temp_end[0], temp_end[1]] == 1:
                self.agents_pos.append(temp_start)
                self.goals_pos.append(temp_end)
                count += 1
        self.agents_pos = np.array(self.agents_pos)
        self.goals_pos = np.array(self.goals_pos)

        self.steps = 0

        self.history = [np.copy(self.agents_pos)]
        if self.punish:
            self.stay_step = [ 0 for i in range (self.num_agents)]

        if self.setting_of_oscillation:
            self.oscillation = [0 for _ in range (self.num_agents)]
        self.get_dist_map()



    def reset(self, dis):
        dis = int(dis)
        # if self.random_agents:
        self.num_agents = self.num_agents
        # self.obstacle_density = random.choice(config.obstacle_density)
        # self.map = np.random.choice(2, self.map_size,
        #                             p=[1 - self.obstacle_density,
        #                                self.obstacle_density]).astype(
        #     np.float32)


        self.map = np.zeros(self.map_size).astype(np.float32)
        for i in range(config.start_place, self.map_size[0], config.step_stride):
            for j in range(config.start_place,self.map_size[0], config.step_stride):
                self.map[i:i + 2, j:j + 2] = 1

        count = 0

        self.agents_pos, self.goals_pos = [], []
        while (count < self.num_agents):
            # temp_place = [start,goal]
            temp_start = (np.random.randint(self.map_size[0]),
                          np.random.randint(self.map_size[0]))
            temp_end = (np.random.randint(1, self.map_size[0]),
                        np.random.randint(1, self.map_size[0]))
            goals_dis = abs(temp_end[0] - temp_start[0]) + abs(temp_end[1] - temp_start[1])
            if temp_start not in self.agents_pos and self.map[
                temp_start[0], temp_start[
                    1]] == 0 and temp_end not in self.goals_pos and self.map[
                temp_end[0], temp_end[1]] == 1 and goals_dis < dis:
                self.agents_pos.append(temp_start)
                self.goals_pos.append(temp_end)
                count += 1


        self.agents_pos = np.array(self.agents_pos)
        self.goals_pos = np.array(self.goals_pos)


        self.steps = 0

        self.history = [np.copy(self.agents_pos)]
        if self.punish:
            self.stay_step = [0 for i in range(self.num_agents)]
        if self.setting_of_oscillation:
            self.oscillation = [0 for _ in range (self.num_agents)]
        self.get_dist_map()

        return self.observe()

    def load(self, world: np.ndarray, agents_pos: np.ndarray,
             goals_pos: np.ndarray):

        self.map = np.copy(world)
        self.agents_pos = np.copy(agents_pos)
        self.goals_pos = np.copy(goals_pos)

        self.num_agents = agents_pos.shape[0]

        self.history = [np.copy(self.agents_pos)]

        self.steps = 0

        self.get_dist_map()

    def step(self, actions: List[int]):
        '''
        actions:
            list of indices
                0 stay
                1 up
                2 down
                3 left
                4 right
        '''

        assert len(actions) == self.num_agents, 'actions number' + str(actions)
        # assert all([action_idx<config.action_space and action_idx>=0 for action_idx in actions]), 'action index out of range'

        if np.array_equal(self.agents_pos[0], self.goals_pos[0]) and actions[
            0] != 0:
            print(self.map)
            print(self.steps)
            print(self.agents_pos)
            print(self.goals_pos)
            print(actions)
            raise RuntimeError('action != zero')

        check_id = [i for i in range(self.num_agents)]

        rewards = np.empty(self.num_agents, dtype=np.float32)

        if self.os_random_pick:
            for i in range(self.num_agents):
                if not np.array_equal(self.agents_pos[i],self.goals_pos[i]):
                    try:
                        # 可以考虑改为和 oscillation 一样， history（-1） = history（-3） and history（-1） ！= history（-2）
                        if np.array_equal(self.history[-1][i],self.history[-3][i]) and np.array_equal(self.history[-2][i],self.history[-4][i]):
                            actions[i] = random.randint(1,4)
                    except:
                        pass

        # remove no movement agent id
        for agent_id in check_id.copy():

            if actions[agent_id] == 0:
                # stay
                check_id.remove(agent_id)

                if np.array_equal(self.agents_pos[agent_id],
                                  self.goals_pos[agent_id]):
                    rewards[agent_id] = config.stay_on_goal_reward

                else:
                    rewards[agent_id] = config.stay_off_goal_reward
            else:
                # move
                rewards[agent_id] = config.move_reward

        next_pos = np.copy(self.agents_pos)

        for agent_id in check_id:
            next_pos[agent_id] += action_list[actions[agent_id]]
            # need to debug
            if not (np.any(next_pos[agent_id] < np.array([0, 0])) or np.any(
                    next_pos[agent_id] >= np.asarray(self.map_size))) and \
                    self.dist_map[agent_id,self.agents_pos[agent_id][0], self.agents_pos[agent_id][1]] > \
                    self.dist_map[agent_id, next_pos[agent_id][0], next_pos[agent_id][1]]:
                rewards[agent_id] = self.closer_reward
            else:
                rewards[agent_id] = self.further_reward

        for agent_id in check_id.copy():

            # move
            if np.all(next_pos[agent_id] == self.goals_pos[agent_id]):
                rewards[agent_id] = config.finish_reward

            elif np.any(next_pos[agent_id] < np.array([0, 0])) or np.any(
                    next_pos[agent_id] >= np.asarray(self.map_size)):
                # agent out of bound
                rewards[agent_id] = config.collision_reward
                next_pos[agent_id] = self.agents_pos[agent_id]
                check_id.remove(agent_id)

            elif self.map[tuple(next_pos[agent_id])] == 1:
                # collide obstacle
                rewards[agent_id] = config.collision_reward
                next_pos[agent_id] = self.agents_pos[agent_id]
                check_id.remove(agent_id)

        # agent swap
        for agent_id in check_id:
            if np.any(np.all(next_pos[agent_id] == self.agents_pos, axis=1)):

                target_agent_id = \
                np.where(np.all(next_pos[agent_id] == self.agents_pos, axis=1))[
                    0].item()
                # assert len(target_agent_id) == 1, 'target > 1'

                if np.array_equal(next_pos[target_agent_id],
                                  self.agents_pos[agent_id]):
                    assert target_agent_id in check_id, 'not in check'

                    next_pos[agent_id] = self.agents_pos[agent_id]
                    rewards[agent_id] = config.collision_reward

                    next_pos[target_agent_id] = self.agents_pos[target_agent_id]
                    rewards[target_agent_id] = config.collision_reward

                    check_id.remove(agent_id)
                    check_id.remove(target_agent_id)

        flag = False
        while not flag:

            flag = True
            for agent_id in check_id.copy():

                if np.sum(np.all(next_pos == next_pos[agent_id], axis=1)) > 1:
                    # collide agent

                    collide_agent_id = \
                    np.where(np.all(next_pos == next_pos[agent_id], axis=1))[
                        0].tolist()
                    all_in = True
                    for id in collide_agent_id:
                        if id not in check_id:
                            all_in = False
                            break

                    if not all_in:
                        # agent collide no movement agent
                        collide_agent_id = [id for id in collide_agent_id if
                                            id in check_id]

                    else:

                        collide_agent_pos = next_pos[collide_agent_id].tolist()
                        for pos, id in zip(collide_agent_pos, collide_agent_id):
                            pos.append(id)
                        collide_agent_pos.sort(
                            key=lambda x: x[0] * self.map_size[0] + x[1])

                        collide_agent_id.remove(collide_agent_pos[0][2])

                        # check_id.remove(collide_agent_pos[0][2])

                    next_pos[collide_agent_id] = self.agents_pos[
                        collide_agent_id]
                    for id in collide_agent_id:
                        rewards[id] = config.collision_reward

                    for id in collide_agent_id:
                        check_id.remove(id)

                    flag = False
                    break

        self.history.append(np.copy(next_pos))
        if self.punish:
            self.stay_step = [0 for i in range(self.num_agents)]
        if self.setting_of_oscillation:
            self.oscillation = [0 for _ in range (self.num_agents)]

        arrive_or_not = []
        for agent_id in range(self.num_agents):
            if not (np.array_equal(self.agents_pos[agent_id],self.goals_pos[agent_id])):
                arrive_or_not.append(agent_id)
        if self.punish:
            for i in arrive_or_not:
                try:
                    if np.all(self.history[-1][i] == self.history[-2][i]):
                        self.stay_step[i] = 1
                        if np.all(self.history[-2][i] == self.history[-3][i]):
                            rewards[i] *= config.punish_factor
                            self.stay_step[i] = 2
                            if np.all(self.history[-3][i] == self.history[-4][i]):
                                rewards[i] *= config.punish_factor
                                self.stay_step[i] = 3
                except:
                    pass

        if self.setting_of_oscillation:
            for i in arrive_or_not:
                try:
                    if np.all(self.history[-1][i] == self.history[-3][i]) and \
                            not np.all(self.history[-1][i] == self.history[-2][i]):
                        self.oscillation[i] = 1
                        rewards[i] = config.oscillation_reward

                except:
                    pass
        reward = []

        for i in range(self.num_agents):
            # on goal
            if self.dist_map[i, next_pos[i][0], next_pos[i][1]] == 0:
                if np.all(np.equal(self.agents_pos[i], next_pos[i])):
                    reward.append(config.stay_on_goal_reward)
                else:
                    reward.append(config.finish_reward)

            elif self.dist_map[i,self.agents_pos[i][0], self.agents_pos[i][1]] > \
                    self.dist_map[i, next_pos[i][0], next_pos[i][1]]:
                reward.append(self.closer_reward)

            elif self.dist_map[i,self.agents_pos[i][0], self.agents_pos[i][1]] < \
                    self.dist_map[i, next_pos[i][0], next_pos[i][1]]:
                reward.append(self.further_reward)

            elif np.all(np.equal(self.agents_pos[i], next_pos[i])):
                reward.append(config.stay_off_goal_reward)

        self.agents_pos = np.copy(next_pos)
        self.steps += 1

        # check done
        done = [False for i in range(self.num_agents)]
        for i in range(self.num_agents):
            if np.array_equal(self.agents_pos[i], self.goals_pos[i]):
                done[i] = True
                if actions[i] != 0:
                    rewards[i] = config.finish_reward

        info = {'step': self.steps - 1}

        if np.unique(self.agents_pos, axis=0).shape[0] < self.num_agents:
            print(self.steps)
            print(self.map)
            print(self.agents_pos)
            print(self.history[-1])
            raise RuntimeError('unique')

        current_map = copy.deepcopy(self.map)
        for i in range (self.num_agents):
            current_map[self.agents_pos[i][0]][self.agents_pos[i][1]] = i+10

        return self.observe(), reward, done, info



    def observe(self):
    # need to debug, check observe in environment and observe in test_environment is same or not

        not_active = []
        for i in range(self.num_agents):
            if np.array_equal(self.agents_pos[i], self.goals_pos[i]):
                not_active.append(i)

        obs = np.ones((self.num_agents, 4+config.history_steps, self.map_size[0], self.map_size[1]), dtype=np.bool)

        #   in obstacle_map
        #   0: obstacle
        #   1: free space
        obstacle_map = np.pad(~(self.map.astype(bool)) + 0, self.obs_dim, 'constant',
                              constant_values=0)

        agent_map = np.ones((self.map_size), dtype=np.bool)
        agent_map[self.agents_pos[:,0], self.agents_pos[:,1]] = 0
        for k in not_active:
            agent_map[self.agents_pos[k,0],self.agents_pos[k,1]] = 1
        # agent_map = np.pad(agent_map, self.obs_dim, 'constant', constant_values=1)
        agent_map = agent_map.astype(bool) + 0

        agent_loc = np.ones((self.num_agents, self.map_size[0], self.map_size[1]), dtype=np.bool)
        for i in range(self.num_agents):
            agent_loc[i] = agent_map
            agent_loc[i][self.agents_pos[i][0]][self.agents_pos[i][1]] = 1
        agent_loc = np.pad(agent_loc,((0,0),self.obs_dim,self.obs_dim), 'constant', constant_values= 1)

        history_map = np.ones((self.num_agents,config.history_steps,
                             self.map_size[0]+2*self.obs_dim[0],self.map_size[1]+2*self.obs_dim[1]))

        for i in range(self.num_agents):
            other_agents = [id for id in range(self.num_agents) if id != i]
            for step in range(config.history_steps):
                for id in other_agents:
                    obs[i, 1 + config.history_steps - step][
                        tuple(self.history[max(self.steps - step, 0)][id])] = 0
                history_map[i][step] = np.pad(
                    obs[i, 1 + config.history_steps - step].astype(bool) + 0,
                    self.obs_dim, 'constant', constant_values=1)

        # 四维辅助向量， 当我们的目标点是在障碍物时通过辅助向量也可以帮助机器人走到目标点
        # 当我们的目标点是在障碍物时，通过将临时观测地图中目标点置零
        #all_pos dim0:up   dim1:down  dim2:left dim3: right
        all_pos = np.zeros((self.num_agents, 4))

        for i in range(self.num_agents):
            if self.agents_pos[i][0]+1 < self.map_size[0] \
                    and self.dist_map[i,self.agents_pos[i][0], self.agents_pos[i][1]] > self.dist_map[i, self.agents_pos[i][0]+1,self.agents_pos[i][1]]:
                all_pos[i][1] = 1
            elif self.agents_pos[i][0]-1 != -1 \
                    and self.dist_map[i,self.agents_pos[i][0], self.agents_pos[i][1]] > self.dist_map[i, self.agents_pos[i][0]-1,self.agents_pos[i][1]]:
                all_pos[i][0] = 1

            if self.agents_pos[i][1]+1 < self.map_size[1] \
                    and self.dist_map[i,self.agents_pos[i][0], self.agents_pos[i][1]] > self.dist_map[i, self.agents_pos[i][0],self.agents_pos[i][1]+1]:
                all_pos[i][3] = 1
            elif self.agents_pos[i][1]-1 != -1 \
                    and self.dist_map[i,self.agents_pos[i][0], self.agents_pos[i][1]] > self.dist_map[i, self.agents_pos[i][0],self.agents_pos[i][1]-1]:
                all_pos[i][2] = 1

        """
        dim1 : other agent position
        dim2 : obstacle map
        dim3 : goal pos in FOV
        dim4 - dim(3+history_step) : history map
        """

        if self.subgoal_or_not:
            dynamic_subgoal = self.reset_subgoal()
            local_obs = np.ones((self.num_agents, config.history_steps + 4,
                                 2 * config.obs_dimension[0] + 1,
                                 2 * config.obs_dimension[1] + 1))

            for i, agents_pos in enumerate(self.agents_pos):
                x, y = agents_pos
                local_obs[i,0] = agent_loc[i,x:x+2*self.obs_dim[0]+1,
                                 y:y+2*self.obs_dim[1]+1]
                local_obs[i,1] = obstacle_map[x:x+2*self.obs_dim[0]+1,
                                 y:y+2*self.obs_dim[1]+1]

                local_obs[i,2] = dynamic_subgoal[i]

                local_obs[i, 3: 3+config.history_steps] = history_map[i,:,
                                   x:x+2*self.obs_dim[0]+1,
                                   y:y+2*self.obs_dim[1]+1]
                local_obs[i, -1, 0, 0] = all_pos[i, 0]
                local_obs[i, -1, 0, 1] = all_pos[i, 1]
                local_obs[i, -1, 0, 2] = all_pos[i, 2]
                local_obs[i, -1, 0, 3] = all_pos[i, 3]
                if self.punish:
                    local_obs[i, -1, 0, 4] = self.stay_step[i]
                if self.setting_of_oscillation:
                    local_obs[i, -1, 0, 5] = self.oscillation[i]


        else:

            local_obs = np.ones((self.num_agents, config.history_steps + 3,
                                 2 * config.obs_dimension[0] + 1,
                                 2 * config.obs_dimension[1] + 1))

            for i, agents_pos in enumerate(self.agents_pos):
                x, y = agents_pos
                local_obs[i, 0] = agent_loc[i, x:x + 2 * self.obs_dim[0] + 1,
                                  y:y + 2 * self.obs_dim[1] + 1]
                local_obs[i, 1] = obstacle_map[x:x + 2 * self.obs_dim[0] + 1,
                                  y:y + 2 * self.obs_dim[1] + 1]

                local_obs[i, 2: 2 + config.history_steps] = history_map[i,:,
                                   x:x+2*self.obs_dim[0]+1,
                                   y:y+2*self.obs_dim[1]+1]
                local_obs[i, -1, 0, 0] = all_pos[i, 0]
                local_obs[i, -1, 0, 1] = all_pos[i, 1]
                local_obs[i, -1, 0, 2] = all_pos[i, 2]
                local_obs[i, -1, 0, 3] = all_pos[i, 3]
                if self.punish:
                    local_obs[i, -1, 0, 4] = self.stay_step[i]
                if self.setting_of_oscillation:
                    local_obs[i, -1, 0, 5] = self.oscillation[i]

        ### improvement
        #1 add a channel to show whether the goal is within the field of vision
        #2 change the means of expression of goal(now vector)

        return local_obs

    def render(self):
        map = np.copy(self.map)
        for agent_id in range(self.num_agents):
            if np.array_equal(self.agents_pos[agent_id],
                              self.goals_pos[agent_id]):
                map[tuple(self.agents_pos[agent_id])] = 2
            else:
                map[tuple(self.agents_pos[agent_id])] = agent_id+3
                map[tuple(self.goals_pos[agent_id])] = agent_id+3

        map = map.astype(np.uint8)
        plt.imshow(color_map[map])
        plt.xlabel('step: {}'.format(self.steps))
        plt.ion()
        plt.show()
        plt.pause(0.5)


    def close(self):
        plt.close()

    def get_dist_map(self):
        # Use Dijkstra to build a shortest-path tree rooted at the goal location

        self.dist_map = np.ones((self.num_agents, self.map_size[0], self.map_size[1]),dtype=np.int32) * 2147483647
        for i in range(self.num_agents):
            goal = (self.goals_pos[i,0], self.goals_pos[i,1])
            open_list = []
            closed_list = dict()
            root = {'loc': goal, 'cost': 0}
            heapq.heappush(open_list, (root['cost'], goal, root))
            closed_list[goal] = root
            while len(open_list) > 0:
                (cost, loc, curr) = heapq.heappop(open_list)
                for dir in range(4):
                    child_loc = move(loc, dir)
                    child_cost = cost + 1

                    if child_loc[0] < 0 or child_loc[0] >= self.map.shape[0] or \
                            child_loc[1] < 0 or child_loc[1] >= self.map.shape[1]:
                        continue

                    if self.map[child_loc[0], child_loc[1]] == 1:
                        continue

                    child = {'loc': child_loc, 'cost': child_cost}
                    if child_loc in closed_list:
                        existing_node = closed_list[child_loc]
                        if existing_node['cost'] > child_cost:
                            closed_list[child_loc] = child
                            # open_list.delete((existing_node['cost'], existing_node['loc'], existing_node))
                            heapq.heappush(open_list,
                                           (child_cost, child_loc, child))
                    else:
                        closed_list[child_loc] = child
                        heapq.heappush(open_list, (child_cost, child_loc, child))

            # build the heuristics table
            # h_values = dict()
            for loc, node in closed_list.items():
                # h_values[loc] = node['cost']
                self.dist_map[i,loc[0],loc[1]] = node['cost']
            # print(1)

    def sort_by_index(self,elem):
        index = self.prior_list.index((elem))
        return index

    def reset_candidate_map(self,agent_id, action, cur_candidate_map):

        index = np.where(cur_candidate_map[agent_id] == action)


        current_map = copy.deepcopy(self.map)
        for i in range (self.num_agents):
            current_map[self.agents_pos[i][0]][self.agents_pos[i][1]] = i+10


        cur_candidate_map[agent_id][index] = -1
        # reset the map of following agent
        reset_part = []
        prior_level = self.prior_list.index(agent_id)
        for i in range(prior_level + 1, self.num_agents):
            reset_part.append(self.prior_list[i])

        # if (agent_id != self.num_agents-1):
        #     for i in range (agent_id+1, self.num_agents):
        #         cur_candidate_map[i] = self.candidate_map[i]

        if (prior_level != self.num_agents - 1):
            for i in reset_part:
                cur_candidate_map[i] = self.candidate_map[i]

        next_action = []

        # debug

        for i in range(self.num_agents):
            temp = np.where(cur_candidate_map[i] != -1)

            next_action.append(cur_candidate_map[i][temp[0][0]])

        return next_action

    # need to debug
    def reset_subgoal(self, mode = "partial"):
        # reset all subgoal:

        temp_dist_map = copy.deepcopy(self.dist_map)
        temp_dist_map = np.pad(temp_dist_map,((0,0),self.obs_dim,self.obs_dim),'constant', constant_values=2147483647)
        final_dist_map = np.ones(
            (self.num_agents, 2 * self.obs_dim[0] + 1, 2 * self.obs_dim[1] + 1))
        local_dist_map = np.ones(
            (self.num_agents, 2 * self.obs_dim[0] + 1, 2 * self.obs_dim[1] + 1))

        self.subgoal = []
        for i, agents_pos in enumerate(self.agents_pos):
            x, y = agents_pos
            local_dist_map[i] = temp_dist_map[i,x:x+2*self.obs_dim[0]+1,y:y+2*self.obs_dim[1]+1]
            index = np.unravel_index(local_dist_map[i].argmin(),
                                     local_dist_map[i].shape)

            self.subgoal.append((x + index[0] - self.obs_dim[0], y + index[1] - self.obs_dim[1]))

            final_dist_map[i, index[0], index[1]] = 0

        return final_dist_map


    # def new_get_dist_map(self):
    #     self.dist_map = np.ones((self.num_agents, *self.obs_dim),
    #                             dtype=np.int32) * 2147483647
    #     for i in range(self.num_agents):
    #         open_list = list()
    #         x, y = tuple(self.subgoal[i])
    #         open_list.append((x, y))
    #         self.dist_map[i, x, y] = 0
    #
    #         while open_list:
    #             x, y = open_list.pop(0)
    #             dist = self.dist_map[i, x, y]
    #
    #             up = x - 1, y
    #             if up[0] >= 0 and self.map[up] == 0 and self.dist_map[
    #                 i, x - 1, y] > dist + 1:
    #                 self.dist_map[i, x - 1, y] = dist + 1
    #                 if up not in open_list:
    #                     open_list.append(up)
    #
    #             down = x + 1, y
    #             if down[0] < self.map_size[0] and self.map[down] == 0 and \
    #                     self.dist_map[i, x + 1, y] > dist + 1:
    #                 self.dist_map[i, x + 1, y] = dist + 1
    #                 if down not in open_list:
    #                     open_list.append(down)
    #
    #             left = x, y - 1
    #             if left[1] >= 0 and self.map[left] == 0 and self.dist_map[
    #                 i, x, y - 1] > dist + 1:
    #                 self.dist_map[i, x, y - 1] = dist + 1
    #                 if left not in open_list:
    #                     open_list.append(left)
    #
    #             right = x, y + 1
    #             if right[1] < self.map_size[1] and self.map[right] == 0 and \
    #                     self.dist_map[i, x, y + 1] > dist + 1:
    #                 self.dist_map[i, x, y + 1] = dist + 1
    #                 if right not in open_list:
    #                     open_list.append(right)
    #
    #     self.temp_dist_map = self.dist_map
    #
    #     self.navi_map = np.zeros((self.num_agents, 4, *self.map_size),
    #                              dtype=np.bool)
    #
    #     for x in range(self.map_size[0]):
    #         for y in range(self.map_size[1]):
    #             if self.map[x, y] == 0:
    #                 for i in range(self.num_agents):
    #
    #                     """
    #                     1: up
    #                     2: down
    #                     3: left
    #                     4: right
    #                     """
    #
    #                     if x > 0 and self.dist_map[i, x - 1, y] < self.dist_map[
    #                         i, x, y]:
    #                         assert self.dist_map[i, x - 1, y] == self.dist_map[
    #                             i, x, y] - 1
    #                         self.navi_map[i, 0, x, y] = 1
    #
    #                     if x < self.map_size[0] - 1 and self.dist_map[
    #                         i, x + 1, y] < self.dist_map[i, x, y]:
    #                         assert self.dist_map[i, x + 1, y] == self.dist_map[
    #                             i, x, y] - 1
    #                         self.navi_map[i, 1, x, y] = 1
    #
    #                     if y > 0 and self.dist_map[i, x, y - 1] < self.dist_map[
    #                         i, x, y]:
    #                         assert self.dist_map[i, x, y - 1] == self.dist_map[
    #                             i, x, y] - 1
    #                         self.navi_map[i, 2, x, y] = 1
    #
    #                     if y < self.map_size[1] - 1 and self.dist_map[
    #                         i, x, y + 1] < self.dist_map[i, x, y]:
    #                         assert self.dist_map[i, x, y + 1] == self.dist_map[
    #                             i, x, y] - 1
    #                         self.navi_map[i, 3, x, y] = 1
    #
    #     self.navi_map = np.pad(self.navi_map, (
    #     (0, 0), (0, 0), (self.obs_dim[0], self.obs_dim[1]),
    #     (self.obs_dim[0], self.obs_dim[1])))
