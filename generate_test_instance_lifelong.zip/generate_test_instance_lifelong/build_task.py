import random
import numpy as np
import torch
import os
import time
from random import sample
import pickle

def seed_torch(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def get_all_shelf_pos(map_type, map_size):
    shelf_set = []
    if map_type == 'wide_aisle_warehouse':
        for i in range(2, map_size, 4):
            for j in range(2, map_size, 4):
                shelf_set.append([i, j])
                shelf_set.append([i, j + 1])
                shelf_set.append([i + 1, j])
                shelf_set.append([i + 1, j + 1])
        # print('The shelf num of map_size',map_size, 'is:', len(shelf_set))
        # print('the shelf ratio is:',len(shelf_set)/(map_size * map_size))
    if map_type == 'narrow_aisle_warehouse': # 3*2
        for i in range(1, map_size, 4):
            for j in range(1, map_size, 3):
                shelf_set.append([i,j])
                if j+1 < map_size:
                    shelf_set.append([i, j+1])
                if i+1<map_size:
                    shelf_set.append([i+1, j])
                if i+1<map_size and j+1<map_size:
                    shelf_set.append([i+1, j+1])
                if i+2<map_size:
                    shelf_set.append([i+2, j])
                if i+2<map_size and j+1 <map_size:
                    shelf_set.append([i+2, j+1])
    if map_type == 'narrow_aisle_warehouse_2_2':
        for i in range(1, map_size, 3):
            for j in range(1, map_size, 3):
                shelf_set.append([i,j])
                if j+1 < map_size:
                    shelf_set.append([i, j+1])
                if i+1<map_size:
                    shelf_set.append([i+1, j])
                if i+1<map_size and j+1<map_size:
                    shelf_set.append([i+1, j+1])
                if i+2<map_size:
                    shelf_set.append([i+2, j])
                if i+2<map_size and j+1 <map_size:
                    shelf_set.append([i+2, j+1])

    return shelf_set

if __name__ == '__main__':
    seed_torch(0)
    device = "cpu"
    if device == "cpu":
        os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

    map_type = 'narrow_aisle_warehouse_2_2'
    for map_size in [100,200]: # 34, 82
        if map_size < 100:
            test_num = 1000
        else:
            test_num = 50
        for number_of_agent in [500,1000]: # 10,30,50,70,90

            oneshot_instance_directory = '../instances_oneshot/{}/instance_of_map_{}'.format(map_type, map_size)
            instance_file = oneshot_instance_directory + '/test{}_{}_{}.pkl'.format(map_size, number_of_agent, test_num)
            with open(instance_file, 'rb') as f:
                tests = pickle.load(f)
            goals_pos_set = tests['goals'][0]
            goals_pos = []
            for i in range(len(goals_pos_set)):
                goals_pos.append([goals_pos_set[i][0], goals_pos_set[i][1]])
            # 找到所有货架的位置
            shelf_set = get_all_shelf_pos(map_type, map_size)
            start_time = time.time()
            potential_goals_set = []
            for i in range(len(shelf_set)):
                potential_goals_set.append(shelf_set[i])
            for i in range(len(goals_pos)):
                potential_goals_set.remove(goals_pos[i])
            task_set = sample(potential_goals_set, len(potential_goals_set))
            time_generate_task = time.time() - start_time

            print('The task generator of map_size', map_size, 'agent_num', number_of_agent,
                  'has been completed! the task num is:', len(task_set), 'the time is:', time_generate_task)

            # 输出 task set
            lifelong_instance_directory = '../instances_lifelong/{}/instance_of_map_{}'.format(map_type, map_size)
            if not os.path.exists(lifelong_instance_directory):
                os.system(r"mkdir {}".format(lifelong_instance_directory))
            with open(lifelong_instance_directory + '/tasks_map_{}_agent_{}.pk'.format(map_size, number_of_agent), 'wb') as f:
                pickle.dump(task_set, f)
            #
            # time_file = open(instance_directory + '/tasks_map_{}_agent_{}.txt'.format(map_size, number_of_agent), 'a')
            # time_file.write(str(task_set) + '\n')
            # time_file.close()
