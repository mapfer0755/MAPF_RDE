test34_16_1000 包含 1000 个测试算例，每个算例包含map、start position、goal position。

在进行lifelong测试时，我们只是用第一个算例

